import mysql.connector

def obtener_conexion():
    return mysql.connector.connect(
        host='localhost',
        user='root',   
        password='',     
        database='hospital_tehuacan'
    )

def validar_usuario(correo, password):
    db = obtener_conexion()
    cursor = db.cursor(dictionary=True)
    
    # Consulta segura usando parámetros para evitar Inyección SQL
    query = "SELECT * FROM usuarios WHERE correo = %s AND password = %s"
    cursor.execute(query, (correo, password))
    
    usuario = cursor.fetchone()
    cursor.close()
    db.close()
    
    return usuario # Retorna los datos del médico o None si falló
const searchMed = document.getElementById('buscadorMedicamentos');
if (searchMed) {
    searchMed.addEventListener('keyup', function() {
        let filtro = this.value.toLowerCase(); 
        document.querySelectorAll('#accordionMedicamentos .accordion-item').forEach(function(cat) {
            let coincidencia = false;
            cat.querySelectorAll('tbody tr').forEach(function(fila) {
                if(fila.innerText.toLowerCase().includes(filtro)) {
                    fila.style.display = ''; coincidencia = true;
                } else { fila.style.display = 'none'; }
            });
            let panel = cat.querySelector('.accordion-collapse');
            if (filtro !== "" && coincidencia) { cat.style.display = ''; panel.classList.add('show'); }
            else if (filtro === "") { cat.style.display = ''; }
            else { cat.style.display = 'none'; }
        });
    });
}

document.querySelectorAll('.buscador-pacientes').forEach(function(input) {
    input.addEventListener('keyup', function() {
        let filtro = this.value.toLowerCase();
        document.querySelectorAll('.tab-pane .accordion-item').forEach(function(item) {
            item.style.display = item.innerText.toLowerCase().includes(filtro) ? '' : 'none';
        });
    });
});
from flask import Flask, render_template, request, redirect, url_for, session
from database import obtener_conexion, validar_usuario 

app = Flask(__name__)
app.secret_key = 'hospital_tehuacan_secreto'

@app.route('/')
def index():
    if 'usuario_id' in session:
        return redirect(url_for('inicio'))
    return render_template('index.html')

def registrar_en_bitacora(id_usuario, nombre, evento):
    try:
        ip = request.remote_addr
        db = obtener_conexion(); cursor = db.cursor()
        cursor.execute("INSERT INTO bitacora_accesos (id_usuario, nombre_usuario, evento, ip_maquina) VALUES (%s, %s, %s, %s)", (id_usuario, nombre, evento, ip))
        db.commit(); cursor.close(); db.close()
    except:
        pass 

@app.route('/login', methods=['POST'])
def login():
    correo = request.form.get('correo')
    password = request.form.get('contraseña')
    medico = validar_usuario(correo, password)
    
    if medico:
        session['usuario_id'] = medico['id_usuario']
        session['nombre'] = medico['nombre']
        session['rol'] = medico.get('rol', 'medico') 
        
        registrar_en_bitacora(medico['id_usuario'], medico['nombre'], 'Inicio de Sesión')
        if session['rol'] == 'admin':
            return redirect(url_for('gestion_usuarios'))
        return redirect(url_for('inicio'))
    else:
        registrar_en_bitacora(None, correo, 'Intento Fallido')
        return "Error: Correo o contraseña incorrectos"


@app.route('/inicio')
def inicio():
    if 'usuario_id' in session:
        return render_template('inicioMedico.html', nombre_medico=session['nombre'])
    return redirect(url_for('index'))

@app.route('/consultas')
def consultas():
    if 'usuario_id' in session: return render_template('consulta.html') 
    return redirect(url_for('index'))

@app.route('/medicamentos')
def medicamentos():
    if 'usuario_id' not in session: return redirect(url_for('index'))
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM medicamentos ORDER BY nombre_generico ASC")
    todos_los_medicamentos = cursor.fetchall()
    cursor.close(); db.close()
    
    medicamentos_agrupados = {}
    for med in todos_los_medicamentos:
        cat = med['categoria']
        if cat not in medicamentos_agrupados: medicamentos_agrupados[cat] = []
        medicamentos_agrupados[cat].append(med)
        
    categorias_oficiales = ["Analgésicos", "Antiinflamatorios", "Antibióticos", "Antipiréticos", "Antialérgicos", "Antiácidos/Antiulcerosos", "Antidiarreicos y Laxantes"]
    return render_template('medicamentos.html', medicamentos_por_categoria=medicamentos_agrupados, lista_categorias=categorias_oficiales)

@app.route('/buscar_paciente', methods=['POST'])
def buscar_paciente():
    if 'usuario_id' not in session: return redirect(url_for('index'))
    termino = f"%{request.form.get('busqueda', '')}%"
    
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM pacientes WHERE nombre LIKE %s OR numero_expediente LIKE %s ORDER BY nombre ASC", (termino, termino))
    resultados = cursor.fetchall()
    cursor.execute("SELECT * FROM consultas ORDER BY fecha DESC")
    todas_consultas = cursor.fetchall()
    cursor.close(); db.close()

    agrupados = {}
    for p in resultados:
        letra = p['nombre'][0].upper()
        if letra not in agrupados: agrupados[letra] = []
        agrupados[letra].append(p)

    notas_agrupadas = {}
    for c in todas_consultas:
        id_p = c['id_paciente']
        if id_p not in notas_agrupadas: notas_agrupadas[id_p] = []
        notas_agrupadas[id_p].append(c)
        
    return render_template('pacientes.html', pacientes_por_letra=agrupados, notas_por_paciente=notas_agrupadas, abecedario="ABCDEFGHIJKLMNOPQRSTUVWXYZ")

@app.route('/pacientes')
def pacientes():
    if 'usuario_id' not in session: return redirect(url_for('index'))
    
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM pacientes ORDER BY nombre ASC")
    todos = cursor.fetchall()
    cursor.execute("SELECT * FROM consultas ORDER BY fecha DESC")
    todas_consultas = cursor.fetchall()
    cursor.close(); db.close()
    
    agrupados = {}
    for p in todos:
        letra = p['nombre'][0].upper()
        if letra not in agrupados: agrupados[letra] = []
        agrupados[letra].append(p)
        
    notas_agrupadas = {}
    for c in todas_consultas:
        id_p = c['id_paciente']
        if id_p not in notas_agrupadas: notas_agrupadas[id_p] = []
        notas_agrupadas[id_p].append(c)
    return render_template('pacientes.html', pacientes_por_letra=agrupados, notas_por_paciente=notas_agrupadas, abecedario="ABCDEFGHIJKLMNOPQRSTUVWXYZ")

@app.route('/nuevoPaciente', methods=['GET', 'POST'])
def nuevoPaciente():
    if 'usuario_id' not in session: return redirect(url_for('index'))
    if request.method == 'POST':
        datos = (request.form.get('numero_expediente'), request.form.get('nombre'), request.form.get('fecha_nacimiento'), 
                 request.form.get('sexo'), request.form.get('curp'), request.form.get('telefono'), request.form.get('direccion'))
        try:
            db = obtener_conexion(); cursor = db.cursor()
            cursor.execute("INSERT INTO pacientes (numero_expediente, nombre, fecha_nacimiento, sexo, curp, telefono, direccion) " \
            "VALUES (%s, %s, %s, %s, %s, %s, %s)", datos)
            db.commit(); cursor.close(); db.close()
            return redirect(url_for('pacientes'))
        except Exception as e: return f"Error: {str(e)}"
            
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT MAX(id_paciente) as max_id FROM pacientes")
    res = cursor.fetchone()
    nuevo_exp = f"EXP-{10000 + (res['max_id'] or 0) + 1}"
    cursor.close(); db.close()
    return render_template('nuevoPaciente.html', expediente_generado=nuevo_exp)


@app.route('/nuevaNota/<int:id_paciente>', methods=['GET', 'POST'])
def nuevaNota(id_paciente):
    if 'usuario_id' not in session: return redirect(url_for('index'))
    
    if request.method == 'POST':
        datos = (
            id_paciente,
            request.form.get('peso'),
            request.form.get('talla'),
            request.form.get('presion_arterial'),
            request.form.get('temperatura'),
            request.form.get('diagnostico'),
            request.form.get('tratamiento')
        )
        try:
            db = obtener_conexion(); cursor = db.cursor()
            cursor.execute("""INSERT INTO consultas 
                           (id_paciente, peso, talla, presion_arterial, temperatura, diagnostico, tratamiento) 
                           VALUES (%s, %s, %s, %s, %s, %s, %s)""", datos)
            db.commit(); cursor.close(); db.close()
            return redirect(url_for('pacientes'))
        except Exception as e: return f"Error: {str(e)}"

    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id_paciente, nombre, numero_expediente FROM pacientes WHERE id_paciente = %s", (id_paciente,))
    paciente = cursor.fetchone()
    cursor.close(); db.close()

    return render_template('nuevaNota.html', paciente=paciente)

@app.route('/admin/usuarios')
def gestion_usuarios():
    if 'usuario_id' not in session or session.get('rol') != 'admin': 
        return redirect(url_for('index'))
    
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id_usuario, nombre, correo, rol FROM usuarios ORDER BY nombre ASC")
    lista_usuarios = cursor.fetchall()
    cursor.close(); db.close()
    
    return render_template('admin_usuarios.html', usuarios=lista_usuarios)

@app.route('/registrar_usuario', methods=['POST'])
def registrar_usuario():
    if 'usuario_id' not in session or session.get('rol') != 'admin': 
        return redirect(url_for('index'))
        
    datos = (
        request.form.get('nombre'), 
        request.form.get('correo'), 
        request.form.get('password'), 
        request.form.get('rol')
    )
    try:
        db = obtener_conexion(); cursor = db.cursor()
        cursor.execute("INSERT INTO usuarios (nombre, correo, password, rol) VALUES (%s, %s, %s, %s)", datos)
        db.commit(); cursor.close(); db.close()
        return redirect(url_for('gestion_usuarios'))
    except Exception as e: 
        return f"Error al registrar: {str(e)}"

@app.route('/admin/bitacora')
def ver_bitacora():
    if 'usuario_id' not in session or session.get('rol') != 'admin': 
        return redirect(url_for('index'))
        
    db = obtener_conexion(); cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM bitacora_accesos ORDER BY fecha_acceso DESC")
    lista_logs = cursor.fetchall()
    cursor.close(); db.close()
    
    return render_template('admin_bitacora.html', logs=lista_logs)


@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('index'))

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if 'usuario_id' in session: 
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        datos = (
            request.form.get('nombre'),
            request.form.get('apellidos'),
            request.form.get('fecha'),          
            request.form.get('telefono'),
            request.form.get('matricula'),
            request.form.get('especialidad'),
            request.form.get('correo'),
            request.form.get('contraseña'),    
            request.form.get('rol')
        )
        try:
            db = obtener_conexion()
            cursor = db.cursor()
            sql = """INSERT INTO usuarios 
                     (nombre, apellidos, fecha_nacimiento, telefono, matricula, especialidad, correo, password, rol) 
                     VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"""
            cursor.execute(sql, datos)
            db.commit()
            cursor.close()
            db.close()
            return redirect(url_for('index'))
            
        except Exception as e:
            return f"Error en la base de datos al registrar: {str(e)}"
    return render_template('registro.html')

if __name__ == '__main__': app.run(debug=True)